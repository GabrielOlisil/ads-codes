﻿using static Vetores.Atividades;

/*Atividade2();
Atividade3();
Atividade7();
Atividade8();*/
Atividade9();
